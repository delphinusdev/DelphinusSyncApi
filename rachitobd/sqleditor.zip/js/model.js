// js/model.js

/**
 * Representa una única columna en una tabla.
 */
export class Column {
    constructor(name) {
        this.name = name;
        // Futuro: se podrían añadir dataType, isNullable, etc.
    }
}

/**
 * Representa un objeto de base de datos que puede contener columnas (Tabla o Vista).
 */
export class SchemaObject {
    constructor(name) {
        this.name = name;
        this.columns = []; // Un array de instancias de Column
    }

    /**
     * Añade una columna a este objeto.
     * @param {Column} column - La instancia de la columna a añadir.
     */
    addColumn(column) {
        this.columns.push(column);
    }
}

/**
 * Representa un objeto de base de datos que no tiene columnas (Procedimiento o Función).
 */
export class RoutableObject {
    constructor(name) {
        this.name = name;
    }
}


/**
 * Representa una base de datos individual y contiene todos sus objetos.
 */
export class Database {
    constructor(name) {
        this.name = name;
        this.tables = new Map();
        this.views = new Map();
        this.procedures = new Map();
        this.functions = new Map();
    }

    /**
     * Añade un objeto (tabla, vista, etc.) a la base de datos.
     * @param {string} type - 'Tables', 'Views', 'Procedures', 'Functions'
     * @param {SchemaObject | RoutableObject} object - La instancia del objeto.
     */
    addObject(type, object) {
        const collection = this[type.toLowerCase()];
        if (collection && !collection.has(object.name)) {
            collection.set(object.name, object);
        }
    }
    
    /**
     * Obtiene una tabla o vista por su nombre.
     * @param {string} name - El nombre de la tabla o vista.
     * @returns {SchemaObject | undefined}
     */
    getTableOrViewByName(name) {
        return this.tables.get(name) || this.views.get(name);
    }
}


/**
 * Clase principal del modelo. Actúa como un Singleton para contener todo el estado del esquema.
 * Solo debe haber una instancia de esta clase en toda la aplicación.
 */
export class SchemaModel {
    constructor() {
        if (SchemaModel.instance) {
            return SchemaModel.instance;
        }
        this.databases = new Map(); // Un mapa de instancias de Database
        this.currentDatabaseName = null;
        SchemaModel.instance = this;
    }

    /**
     * Añade una base de datos al modelo.
     * @param {Database} db - La instancia de la base de datos.
     */
    addDatabase(db) {
        if (!this.databases.has(db.name)) {
            this.databases.set(db.name, db);
        }
    }

    /**
     * Obtiene una base de datos por su nombre.
     * @param {string} name - El nombre de la base de datos.
     * @returns {Database | undefined}
     */
    getDatabase(name) {
        return this.databases.get(name);
    }

    /**
     * Establece la base de datos activa.
     * @param {string} name - El nombre de la base de datos.
     */
    setCurrentDatabase(name) {
        if (this.databases.has(name)) {
            this.currentDatabaseName = name;
        }
    }

    /**
     * Obtiene la instancia de la base de datos activa actualmente.
     * @returns {Database | undefined}
     */
    getCurrentDatabase() {
        return this.getDatabase(this.currentDatabaseName);
    }
}