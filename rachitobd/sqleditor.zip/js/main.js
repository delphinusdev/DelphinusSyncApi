import * as api from './api.js';
import * as ui from './ui.js';
import * as sidebar from './sidebar.js';
import * as editor from './editor.js';
import * as table from './table.js';
// <-- CAMBIO: Importar todas las clases necesarias del modelo
import { SchemaModel, Database, SchemaObject, Column, RoutableObject } from './model.js';

// --- Estado de la Aplicación ---
let monacoEditorInstance;
const schemaModel = new SchemaModel();

// --- Lógica Principal de la Aplicación ---

/**
 * Toma los datos crudos del API y los usa para poblar nuestro modelo de datos.
 * @param {string} dbName - El nombre de la base de datos a poblar.
 * @param {object} rawSchemaData - El objeto JSON crudo del API get_schema.php.
 */
function populateModelFromRawData(dbName, rawSchemaData) {
    const db = new Database(dbName);

    for (const objectType in rawSchemaData) { // objectType es 'Tables', 'Views', etc.
        const objects = rawSchemaData[objectType];
        for (const objectName in objects) {
            
            if (objectType === 'Tables' || objectType === 'Views') {
                const schemaObject = new SchemaObject(objectName);
                const columns = objects[objectName].columns || [];
                columns.forEach(colName => {
                    schemaObject.addColumn(new Column(colName));
                });
                db.addObject(objectType, schemaObject);

            } else if (objectType === 'Procedures' || objectType === 'Functions') {
                const routableObject = new RoutableObject(objectName);
                db.addObject(objectType, routableObject);
            }
        }
    }
    
    schemaModel.addDatabase(db);
}


/**
 * Carga el esquema, lo cachea y actualiza la UI.
 * AHORA USA EL MODELO.
 */
async function loadSchemaAndUpdateUI() {
    const dbName = schemaModel.currentDatabaseName;
    const schemaStatusSpan = document.getElementById('schemaStatus');
    
    // Si la base de datos ya está en nuestro modelo, la usamos directamente.
    if (schemaModel.getDatabase(dbName)) {
        schemaStatusSpan.textContent = `Esquema (${dbName} - Modelo)`;
        sidebar.populateSchemaSidebar(schemaModel.getCurrentDatabase());
        editor.registerMonacoCompletionProvider(monacoEditorInstance, schemaModel.getCurrentDatabase());
        return;
    }
    
    // Si no, la buscamos en el API.
    schemaStatusSpan.textContent = `Cargando esquema (${dbName})...`;
    try {
        const rawData = await api.fetchSchema();
        if (Object.keys(rawData).length > 0 && rawData.success !== false) {
            // Llenamos nuestro modelo con los datos crudos.
            populateModelFromRawData(dbName, rawData);
            
            schemaStatusSpan.textContent = `Esquema (${dbName} - OK)`;
            sidebar.populateSchemaSidebar(schemaModel.getCurrentDatabase());
            editor.registerMonacoCompletionProvider(monacoEditorInstance, schemaModel.getCurrentDatabase());
        } else {
            schemaStatusSpan.textContent = `Esquema (${dbName} - Vacío)`;
        }
    } catch (error) {
        schemaStatusSpan.textContent = `Error Esquema (${dbName})`;
        ui.showStatusMessage(`Error al cargar el esquema: ${error.message}`, 'error');
    }
}
async function handleExecuteQuery() {
    const selection = monacoEditorInstance.getSelection();
    const query = monacoEditorInstance.getModel().getValueInRange(selection).trim() || monacoEditorInstance.getValue();
    if (!query.trim()) return;

    document.getElementById('executeButton').disabled = true;
    try {
        const result = await api.runQuery(query);
        if (result.success) {
            if (result.columns && result.rows) {
                table.createResultsTable(result);
                ui.showStatusMessage(`Éxito: ${result.rows.length} filas encontradas.`, 'success');
            } else {
                ui.showStatusMessage(`Éxito: ${result.message || ''} ${result.rowsAffected !== undefined ? `${result.rowsAffected} filas afectadas.` : ''}`, 'success');
            }
        } else {
            ui.showStatusMessage(`Error: ${result.message}`, 'error');
        }
    } catch (error) {
        ui.showStatusMessage(`Error de Conexión: ${error.message}`, 'error');
    } finally {
        document.getElementById('executeButton').disabled = false;
    }
}

/**
 * Manejador para cambiar de base de datos.
 */
async function handleSwitchDatabase(event) {
    const newDatabase = event.target.value;
    // <-- CAMBIO: Usar el nombre de la DB del modelo para la comparación
    if (!newDatabase || newDatabase === schemaModel.currentDatabaseName) return;

    ui.showStatusMessage(`Cambiando a: ${newDatabase}...`, 'info', 2000);
    try {
        const result = await api.setCurrentDatabase(newDatabase);
        if (result.success) {
            // <-- CAMBIO: Actualizar el estado a través del modelo
            schemaModel.setCurrentDatabase(newDatabase);
            document.getElementById('currentDatabaseDisplay').textContent = `Base de datos: ${newDatabase}`;
            await loadSchemaAndUpdateUI();
        } else {
            ui.showStatusMessage(`Error al cambiar: ${result.message}`, 'error');
            event.target.value = schemaModel.currentDatabaseName;
        }
    } catch (error) {
        ui.showStatusMessage(`Error de conexión: ${error.message}`, 'error');
        event.target.value = schemaModel.currentDatabaseName;
    }
}

/**
 * Función de inicialización
 */
async function init() {
    monacoEditorInstance = await editor.initializeEditor();
    
    // Configurar interacciones de la UI
    document.getElementById('executeButton').addEventListener('click', handleExecuteQuery);
    // <-- CAMBIO: Asegúrate de que el botón openFileButton exista en tu HTML
    document.getElementById('openFileButton').addEventListener('click', () => ui.openSqlFile(monacoEditorInstance));
    document.getElementById('refreshSchemaButton').addEventListener('click', () => {
        // <-- CAMBIO: Usar el nombre de la DB del modelo
        const dbName = schemaModel.currentDatabaseName;
        if (dbName) {
            // No es necesario borrar del localStorage, la lógica de loadSchema... ya prefiere el modelo
            // Simplemente forzamos la recarga desde la API invalidando el modelo para esa DB (opcional, más simple es recargar)
            schemaModel.databases.delete(dbName); // Fuerza la recarga
        }
        loadSchemaAndUpdateUI();
    });
    document.getElementById('logoutButton').addEventListener('click', ui.logout);
    document.getElementById('databaseSelector').addEventListener('change', handleSwitchDatabase);

    sidebar.setupSidebarInteractions(monacoEditorInstance);
    sidebar.setupSchemaSearch();

    // El resto de la función init se queda igual...
    const dbSelector = document.getElementById('databaseSelector');
    try {
        const result = await api.fetchDatabases();
        if (result.success && result.databases.length > 0) {
            dbSelector.innerHTML = '';
            result.databases.forEach(dbName => {
                const option = document.createElement('option');
                option.value = dbName;
                option.textContent = dbName;
                dbSelector.appendChild(option);
            });
            const currentDbName = result.currentDatabase || result.databases[0];
            schemaModel.setCurrentDatabase(currentDbName);
            dbSelector.value = currentDbName;
            document.getElementById('currentDatabaseDisplay').textContent = `Base de datos: ${currentDbName}`;
            await loadSchemaAndUpdateUI();
        } else {
            ui.showStatusMessage(result.message || 'No se encontraron bases de datos.', 'error');
        }
    } catch (error) {
        ui.showStatusMessage(`Error cargando bases de datos: ${error.message}`, 'error');
    }
}


// Iniciar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', init);